clear;clc;close all;


J=10.183e-4;%Moment of Inertia of the system
c=0.004; %damping constant of the system
k=0.1; % stiffness constant of the system
R=0.5; %Resistance of the motor
L=0.134;%Motor inductance
ki=0.004; %Motor constant
ke=0.083; %back emf constant
Jm=19e-10; %Motor rotor inertia
bm=0.00123;%motor damping constant
m=43.4; %m [kg]
g=9.81;
x=2; % distance to pivot from cg. 



